var test = require('./test')


test.test.func()